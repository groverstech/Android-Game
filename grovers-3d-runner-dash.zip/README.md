# Grovers 3D Runner Dash (Three.js + Vite)

Quick start template for a 3D runner game.

## Run
```
npm install
npm run dev
```
